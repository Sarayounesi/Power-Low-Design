import random
from tabulate import tabulate
from termcolor import colored

sizes, sa_i = [128, 64, 32, 16, 8, 4, 2], 10000
results = {size: {} for size in sizes}

for size in sizes:
    sequences = [''.join(random.choices(['0', '1'], k=size))
                 for _ in range(sa_i + 1)]

    def count_changes(seq1, seq2):
        return sum(a != b for a, b in zip(seq1, seq2))

    changes_count = sum(count_changes(
        sequences[i], sequences[i + 1]) for i in range(sa_i))
    results[size]['Full Bus'] = round(changes_count / sa_i, 3)

    for part_size in (2**i for i in range(1, size.bit_length())):
        bit_sequences = [''.join(
            bits[j:j + part_size] + '0' for j in range(0, size, part_size)) for bits in sequences]
        changes_count = sum(
            sum(min(count_changes(current[j:j + part_size + 1], next_seq[j:j + part_size + 1]),
                    count_changes(current[j:j + part_size + 1], ''.join('1' if b == '0' else '0' for b in next_seq[j:j + part_size + 1])))
                for j in range(0, size, part_size + 1))
            for current, next_seq in zip(bit_sequences, bit_sequences[1:])
        )
        results[size][part_size] = round(changes_count / sa_i, 3)

partition_sizes = sorted(set(part_size for part_size_dict in results.values(
) for part_size in part_size_dict.keys() if part_size != 'Full Bus'))
headers = ["Bus Configuration"] + \
    [f"Segmented Bus {part_size}" for part_size in partition_sizes] + ["Full Bus"]

table_data = [
    [size] + [results[size].get(part_size, "")
              for part_size in partition_sizes] + [results[size]['Full Bus']]
    for size in sizes
]

best_value = min(value for row in table_data for value in row[1:] if isinstance(
    value, (int, float)))
table_data = [
    [colored(value, "red") if value == best_value else value for value in row] for row in table_data
]

print(tabulate(table_data, headers=headers, tablefmt="grid"))
